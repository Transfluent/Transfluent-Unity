var searchData=
[
  ['builderinstance',['BuilderInstance',['../classtransfluent_1_1_c_i_builder_1_1_builder_instance.html',1,'transfluent::CIBuilder']]]
];
