var searchData=
[
  ['playerprefskeystore',['PlayerPrefsKeyStore',['../classtransfluent_1_1_player_prefs_key_store.html',1,'transfluent']]],
  ['price',['Price',['../classtransfluent_1_1_estimate_translation_cost_v_o_1_1_price.html',1,'transfluent::EstimateTranslationCostVO']]]
];
